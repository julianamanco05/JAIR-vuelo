from flask import Flask, render_template, request
app = Flask(__name__)

#Inicializacion de variables
lista_login=['admin,123,Administrador,31312543']
usuario_sesion=""
lista_ciudades=[]
lista_mapas=[]
lista_vuelos=[]
registro_usuarios_vuelos=[]


@app.route('/')
def index():
    global usuario_sesion,lista_ciudades,lista_vuelos,lista_mapas
    usuario_sesion=""
    lista_ciudades=[]
    lista_vuelos=[]
    lista_mapas=[]
    return render_template ("index.html")
    
@app.route('/user/')
@app.route('/user/<string:user>')
def  user(user="Macbook"):
    return "hola "+ user

@app.route('/number/<int:number>')
def  number(number):
    return "El numero es {}".format(number)


@app.route('/login/', methods=['GET','POST'])
def  login():
    if request.method=='POST':
        usuario= request.form['username']
        clave= request.form['password']
        
        global lista_login
        global usuario_sesion
        global registro_usuarios_vuelos
        acceso=[]
        for   linea in lista_login:
            acceso=linea.split(',')
            if acceso[0]==usuario and acceso[1]==clave:
                usuario_sesion=acceso[2]

                global lista_ciudades
                global lista_vuelos
                global lista_mapas
                archivo = open("vuelos.txt",'r')
                i = 0
                for i,linea in enumerate(archivo):
                    if i>12 and i<36:
                        
                        registro=linea.split(",")
                        ciudad=registro[0]
                        longitud=len(ciudad)
                        
                        iniciales=ciudad[0:3]
                        x=ciudad[10:13]
                        y=ciudad[14:17]
                        ciudad=ciudad[18:longitud]
                        estado=registro[1]
                        
                        registro=[]
                        registro.append(iniciales)
                        registro.append(ciudad)
                        registro.append(estado.rstrip("\n"))

                        registro2=[]
                        registro2.append(iniciales)
                        registro2.append(x)
                        registro2.append(y)

                      

                        lista_mapas.append(registro2)
                        lista_ciudades.append(registro)
                archivo.close()

                archivo = open("vuelos.txt",'r')
                i = 0
                for i,linea in enumerate(archivo):
                    if i>57 :
                        lista_vuelos.append(linea)

                archivo.close()

                registro=[]
                for linea in registro_usuarios_vuelos:
                    if linea[0]==usuario_sesion:
                        registro.append(linea)

                return render_template ("sesion.html",fullname=usuario_sesion, historial_vuelos=registro)
                break


        return render_template ("index.html")


@app.route('/signup_view/')
def signup_view():
    return render_template ("signup.html")


@app.route('/signup_controller/', methods=['GET','POST'])
def signup_controller():
    
    if request.method=='POST':
        
        fullname= request.form['username']
        email= request.form['email']
        clave= request.form['password']
        clave_confirmada= request.form['password_confirmed']
        telefono= request.form['phone']
        global lista_login
        if clave==clave_confirmada:
            registro= email +","+ clave +","+fullname+","+telefono
            lista_login.append(registro)
            return render_template ("index.html")

    return render_template ("signup.html")


@app.route('/reserve_view/')
def reserve_view():
    global usuario_sesion,lista_ciudades
    return render_template ("reserve.html", fullname=usuario_sesion, ciudades=lista_ciudades )



@app.route('/seek_lookfor/',  methods=['GET','POST'])
def  seek_lookfor():
    if request.method=='POST':
        global lista_vuelos
        global usuario_sesion
        global lista_ciudades
        global lista_mapas
        vuelos_usuario=[]
        registro=[]

        
        dato1= request.form['origen']
        dato2= request.form['destino']

        dato1=dato1.split(",")
        dato2=dato2.split(",")

        origen=dato1[0]
        origen_nombre=dato1[1]
        destino=dato2[0] 
        destino_nombre=dato2[1]


        for linea in lista_vuelos:
            posible_origen=linea[8:11]
            posible_destino=linea[19:22]
            if posible_origen==origen and posible_destino==destino:
                aerolinea=linea[0:2]
                vuelo=linea[2:6]
                comidas=linea[30:32]
                paradas=linea[36:37]
                tipo_avion=linea[41:44]
                
                registro=[]
                registro.append(aerolinea)
                registro.append(vuelo)
                registro.append(tipo_avion)
                registro.append(origen_nombre)
                registro.append(destino_nombre)
                registro.append(comidas)
                registro.append(paradas)


                for ubicacion in lista_mapas:
                    if ubicacion[0]==posible_origen:
                        longitud_origen=ubicacion[1]
                        latitud_origen=ubicacion[2]
                    if ubicacion[0]==posible_destino:
                        longitud_destino=ubicacion[1]
                        latitud_destino=ubicacion[2]

                registro.append(longitud_origen)
                registro.append(latitud_origen)
                registro.append(longitud_destino)
                registro.append(latitud_destino)

                vuelos_usuario.append(registro)
        return render_template ("reserve_maps.html", fullname=usuario_sesion, ciudades=lista_ciudades, vuelos_usuario=vuelos_usuario )


@app.route('/save_reserved/',  methods=['GET','POST'])
def  save_reserved():
    global usuario_sesion, registro_usuarios_vuelos
    if request.method=='POST':
       
        vuelo_seleccionado= request.form['vuelo_seleccionado']
        
        vuelo_selecionando=vuelo_seleccionado.split(",")
        registro=[] 
        registro.append(usuario_sesion)
        registro.append(vuelo_selecionando[0])
        registro.append(vuelo_selecionando[1])
        registro.append(vuelo_selecionando[2])
        registro.append(vuelo_selecionando[3])
        registro.append(vuelo_selecionando[4])
        registro.append(vuelo_selecionando[5])
        registro.append(vuelo_selecionando[6])
       
        registro_usuarios_vuelos.append(registro)

        registro=[]
        for linea in registro_usuarios_vuelos:
            if linea[0]==usuario_sesion:
                registro.append(linea)
		
    return render_template ("sesion_historial.html",fullname=usuario_sesion,historial_vuelos=registro )

@app.route('/backup/')
def  backup():
    return render_template ("backup.html" )


@app.route('/backup_process/')
def  backup_process():
    global registro_usuarios_vuelos
    global lista_login

    archivo = open("backup_login.txt",'w')

    for dato in lista_login:
        archivo.write(dato+'\n')

    archivo.close()
    
    archivo = open("backup_vuelos_usuarios.txt",'w')
    for dato in registro_usuarios_vuelos:
        archivo.write(dato[0]+","+dato[1]+","+dato[2]+","+dato[3]+","+dato[4]+","+dato[5]+","+dato[6]+'\n')

    return "Proceso Terminado"


@app.route('/backup_restore/')
def  backup_restore():
    global registro_usuarios_vuelos
    global lista_login



    archivo = open("backup_login.txt",'r')        
    for linea in archivo:       
        lista_login.append(linea)
            
    archivo.close()
    
    archivo = open("backup_vuelos_usuarios.txt",'r')             
   
    for linea2 in archivo:
        x=linea2.split(",")
        registro_usuarios_vuelos.append(x)

    archivo.close()
     
    return render_template ("index.html")


@app.route('/configurar',methods=['GET', 'POST'])
def configuracion():

    global Latitud,Longitud,Salida,Llegada
    
    Latitud=int(request.form['LongitudSalida'])
    Longitud=int(request.form['LatitudSalida'])

    
    entries = {"Latitud":Latitud, "Longitud":Longitud,
               "Salida":Latitud, "Llegada":Longitud}
    print(entries)
    return render_template('juego.html', entries=entries)






if __name__ == "__main__":
    app.run(debug=True)

